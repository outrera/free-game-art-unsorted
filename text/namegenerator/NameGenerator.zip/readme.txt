[=======================]
[ Name Generator Readme ]
[=======================]
by kddekadenz


1.) Instructions
    ============
The archive includes the program as .jar and .sb. It is recomned to use the .sb, because it is faster and the list can be exported. You need Scratch to open the .sb. Rightclick the list to export the names as txt (Scratch only).
There are also a couple of .txt with outputted names.


2.) License
    =======
I do release the code and the lists as CC0, so feel free to do whatever you want with this.
I would like to know for which projects you use the program, please send me a e-mail: kddekadenz.jimdo.com/support
