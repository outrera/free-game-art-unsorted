Almost all the spell_*.base.111.png files are taken from JXClient's source, revision 4199.

They are therefore assumed to be under GPL.

See http://crossfire.svn.sourceforge.net/viewvc/crossfire/trunk/jxclient/default.theme/pictures/spells/?pathrev=4199 for the revision adding them to SVN.
