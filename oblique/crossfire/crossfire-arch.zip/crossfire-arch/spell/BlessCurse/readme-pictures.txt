The "bless_effect.base.11*.png" pictures are variations of http://commons.wikimedia.org/wiki/File:Pentacle_1.svg which is in the public domain.

The "curse_effect.base.11*.png" pictures are variations of http://commons.wikimedia.org/wiki/File:Inverted_Pentagram.svg which is in the public domain.